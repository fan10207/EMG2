package com.example.hp.muscle.helper;

import android.app.Activity;
import android.app.Fragment;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.hp.muscle.R;
import com.example.hp.muscle.helper.bluetooth.AppFragment;
import com.example.hp.muscle.helper.bluetooth.DeviceListActivity;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by hp on 2016/7/28.
 */
public class ParameterFragment extends Fragment implements View.OnClickListener {
    private Context context;
    public static final int REQUEST_ENABLE_BT = 0;
    public static final int REQUEST_CONNECT_DEVICE = 1;
    private BluetoothAdapter mBluetoothAdapter;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
private ChartDemoFragment CHART_FRAGMENT;

    public static final String TAG="bluetooth";
  /*  @InjectView(R.id.bluetooth)
    Button bluetooth;
    @InjectView(R.id.search_bluetooth)
    Button search_bluetooth;*/

    /*public void onCreate(Bundle saveInstanceState) {
        Log.e(TAG, "onCreateView: BTcreate" );

        super.onCreate(saveInstanceState);
    }
*/

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle saveInstanceState) {
        Log.e(TAG, "onCreateView: BTcreateview" );
        View view = inflater.inflate(R.layout.parameter, container, false);
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        return view;

    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        context = getActivity();
        CHART_FRAGMENT=new ChartDemoFragment();
        sharedPreferences = getActivity().getSharedPreferences("address", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        Button bluetooth = (Button) getActivity().findViewById(R.id.bluetooth);
        Button search_bluetooth = (Button) getActivity().findViewById(R.id.search_bluetooth);
        bluetooth.setOnClickListener(this);
        search_bluetooth.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bluetooth: {
                /*if (!mBluetoothAdapter.isEnabled()) {
                    Intent enableIntent = new Intent(
                            BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    // once enableIntent exits,onActivityResult will run with the
                    // Request_code
                    startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
                } else
                    Toast.makeText(context, "bluetooth is already opened",
                            Toast.LENGTH_LONG).show();*/
            }
            break;
            case R.id.search_bluetooth: {
          /*      Log.e("searchbluetooth", "onClick: ");
                Intent serverIntent = new Intent(context, DeviceListActivity.class);
                startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);*/

            }
            break;

        }
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
            Log.d(TAG, "onActivityResult " + resultCode);
        switch (requestCode) {
            case REQUEST_CONNECT_DEVICE:
                // When DeviceListActivity returns with a device to connect
                if (resultCode == Activity.RESULT_OK) {
                    connectDevice(data);
                }
                break;
            case REQUEST_ENABLE_BT:
                // When the request to enable Bluetooth returns
                if (resultCode == Activity.RESULT_OK) {
                    // Bluetooth is now enabled, so set up a chat session
                    // setupChat();
                } else {
                    // User did not enable Bluetooth or an error occurred
                    Log.d(TAG, "BT not enabled");
                    Toast.makeText(context, R.string.bt_not_enabled_leaving,
                            Toast.LENGTH_SHORT).show();
                }
        }
    }



    public void connectDevice(Intent data) {
        String address = data.getExtras().getString(
                DeviceListActivity.EXTRA_DEVICE_ADDRESS);
        editor.putString("address", address);
        editor.commit();
        // Get the BluetoothDevice object
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        // Attempt to connect to the device
        CHART_FRAGMENT.getmChatService().connect(device);
    }

}
