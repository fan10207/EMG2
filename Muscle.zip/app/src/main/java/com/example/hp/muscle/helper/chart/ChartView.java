package com.example.hp.muscle.helper.chart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by hp on 2016/7/18.
 */
public class ChartView extends View {
    private static final String TAG = "ChartView";

    private int POINT_NUM = 16128;
    int cnt;
    //to draw line
    public static final int DRAW_MOVE = 0;
    public static final int DRAN_STILL = 1;
    public static final int SET_START_END = 2;
    public static final int FINISHED=1;
    public static final int UNFINISHED=0;
    private int mdrawstate = DRAW_MOVE;
    private float[] mPoints;
    public float[] comPonts;
    public float[] chosenData;
    private float amplitude = 2000f; //纵坐标幅值
    private float envelopeAmp = 1.0f;
    //points num in the view
    private int count = 0;
    private Rect mRect = new Rect();
    private int yLableLength = 30;
    private Paint mForePaint = new Paint();
    private Paint mLabelPaint = new Paint();
    private Paint p = new Paint();
    private boolean mCycleColor = false;
    private float last[];
    private float envelopeYAxis = 1.0f;
    public float currentX = 0;
    public float currentY = 0;
    public float[] valueabledata;
    public float start_Coordinate = 0;
    public float end_Coordinate = 0;
    public float startPos = 0;
    public float endPos = 0;
    private int finishPoint=UNFINISHED;

    public ChartView(Context context) {
        this(context, null, false);
    }

    public ChartView(Context context, AttributeSet attrs) {
        this(context, attrs, false);
    }

    public ChartView(Context context, AttributeSet attrs, boolean mCycleColor) {
        super(context, attrs);
        this.mCycleColor = mCycleColor;
        initChartView();
    }

    private void initChartView() {
        mPoints = new float[POINT_NUM * 4];
        comPonts = new float[POINT_NUM];
        last = new float[2];
        mForePaint.setStrokeWidth(2f);
        mForePaint.setAntiAlias(true);
        mForePaint.setColor(Color.BLACK);

        p.setStrokeWidth(3f);
        p.setAntiAlias(true);

        mLabelPaint.setTextSize(10);
        mLabelPaint.setColor(Color.BLACK);
    }

    public void setForePaintColor(int color) {
        mForePaint.setColor(color);
    }

    public void setPOINT_NUM(int POINT_NUM) {
        this.POINT_NUM = POINT_NUM;
        cleanChart();
    }

    public int getPOINT_NUM() {
        return POINT_NUM;
    }

    public void setEnvelopeYAxis(float envelopeYAxis) {
        this.envelopeYAxis = envelopeYAxis;
    }

    public void setAmplitude(float amplitude) {
        this.amplitude = amplitude;
    }

    public void setEnvelopeAmp(float envelopeAmp) {
        this.envelopeAmp = envelopeAmp;
    }



    /**
     * update chart from floats data, set our max value as 2000, this value should be changed
     * when your input value is bigger than this value
     *
     * @param floats
     */
    public void updateFloats(float[] floats) {
        if (floats == null || floats.length == 0)
            return;

        if ((count + floats.length) > POINT_NUM) {
            mPoints = new float[POINT_NUM * 4];
            comPonts = new float[POINT_NUM];
            count = 0;
        }

        if (count == 0) {
            cnt = 0; //cnt是一个标志位
        } else {
            cnt = 1;
        }

        //处理断点的情况
        if (cnt == 1) {
            mPoints[(count - 1) * 4] = last[0];
            mPoints[(count - 1) * 4 + 1] = last[1];
            mPoints[(count - 1) * 4 + 2] = (mRect.width() * count / (POINT_NUM - 1));
            mPoints[(count - 1) * 4 + 3] = mRect.height() / 2 * envelopeAmp
                    - (floats[0] / amplitude * (mRect.height() / 2)) * envelopeAmp;
        }

        //画点，两点连成一条直线
        for (int i = 0; i < floats.length - 1; i++) {
            comPonts[count] = floats[i];
            mPoints[count * 4] = (mRect.width() * count / (POINT_NUM - 1));
            mPoints[count * 4 + 1] = mRect.height() / 2 * envelopeAmp
                    - (floats[i] / amplitude * (mRect.height() / 2)) * envelopeAmp;
            mPoints[count * 4 + 2] = (mRect.width() * (count + 1) / (POINT_NUM - 1));
            mPoints[count * 4 + 3] = mRect.height() / 2 * envelopeAmp
                    - (floats[i + 1] / amplitude * (mRect.height() / 2)) * envelopeAmp;
            ++count;
        }

        last[0] = (mRect.width() * count / (POINT_NUM - 1));
        last[1] = mRect.height() / 2 * envelopeAmp
                - (floats[floats.length - 1] / amplitude * (mRect.height() / 2)) * envelopeAmp;
        count += 1;

        //this method will invoke onDraw()
        invalidate();
    }

    public void drawLabel(Canvas canvas) {
        int delta = mRect.height() / 10;
        for (int i = 0; i <= 10; i++) {
            canvas.drawText((float) (Math.round((amplitude - 0.2 * i * amplitude / envelopeYAxis) * 10)) / 10
                    + "", 0, delta * i, mLabelPaint);
        }
    }


    public void cleanChart() {
        Log.e(TAG, "cleanChart: clean");
        mPoints = new float[POINT_NUM * 4];
        count = 0;
        invalidate();
    }

    @Override
    /**
     * 三种画图模式
     * MOVE为接收数据时的模式
     * STILL为计算完起始点后画出有效肌电
     * STAR_END为选取起始点的方法
     */
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        switch (mdrawstate) {
            case DRAW_MOVE:
                if (mCycleColor) {
                    cycleColor();
                }
                mRect.set(0, 0, getWidth(), getHeight());
                drawLabel(canvas);
                canvas.drawLines(mPoints, mForePaint);
                break;
            case DRAN_STILL:
                mRect.set(0, 0, getWidth(), getHeight());
                drawLabel(canvas);
                count = 0;

                for (int i = 0; i < valueabledata.length - 2; i++) {

                    canvas.drawLine(mRect.width() * count / (POINT_NUM - 1),
                            mRect.height() / 2 * envelopeAmp - (valueabledata[i] / amplitude * (mRect.height() / 2)) * envelopeAmp,
                            mRect.width() * (count + 1) / (POINT_NUM - 1),
                            mRect.height() / 2 * envelopeAmp - (valueabledata[i + 1] / amplitude * (mRect.height() / 2)) * envelopeAmp,
                            mForePaint);
                    count++;

                }

                break;
            case SET_START_END:

                drawLabel(canvas);
                canvas.drawLines(mPoints, mForePaint);
                p.setColor(Color.GREEN);
                canvas.drawLine(startPos, mRect.bottom, startPos, mRect.top, p);
                if (start_Coordinate == 0) {

                    startPos = currentX;
                    start_Coordinate = currentX / mRect.right * POINT_NUM;

                } else if (end_Coordinate == 0 && ((currentX - startPos) > 20)) {

                    endPos = currentX;
                    end_Coordinate = currentX / mRect.right * POINT_NUM;
                    p.setColor(Color.RED);
                    canvas.drawLine(currentX, mRect.bottom, currentX, mRect.top, p);
                    finishPoint = FINISHED;
                }

                break;


        }


        //canvas.drawLines(last, mForePaint);

    }

    private float colorCounter = 0;

    private void cycleColor() {
        int r = (int) Math.floor(128 * (Math.sin(colorCounter + 3)));
        int g = (int) Math.floor(128 * (Math.sin(colorCounter + 1) + 1));
        int b = (int) Math.floor(128 * (Math.sin(colorCounter + 7) + 1));
        mForePaint.setColor(Color.argb(128, r, g, b));
        colorCounter += 0.03;
    }

    /**
     *
     * @param event
     * @return 用于取得选取起始点时触屏得到准确位置
     */

    public boolean onTouchEvent(MotionEvent event) {
        if (mdrawstate == SET_START_END) {
            this.currentX = event.getX();
            this.currentY = event.getY();
            if (start_Coordinate == 0 | end_Coordinate == 0)
                invalidate();


        }


        return true;


    }

    /**
     * 用于画出有效肌电信号
     * @param data 选取起始点得到的数组
     */

    public void demValueableData(float[] data) {

        setDrawstate(DRAN_STILL);
        int length = data.length;
        if (length > POINT_NUM) {
            length = POINT_NUM;
        }
        valueabledata = new float[length];//用于记录真正有效的肌电信号

        for (int i = 0; i < length; i++) {
            valueabledata[i] = data[i];
         //   Log.e(TAG, "demValueableData: " + data[i]);
        }
        invalidate();


    }

    public void setLine() {
    }

    /**
     * 改变画图的状态的子函数
     * @param i
     */
    public void setDrawstate(int i) {
        mdrawstate = i;
    }

    public int getDrawstate() {
        return mdrawstate;
    }

    public void stopDrawing() {
        setDrawstate(SET_START_END);
    }

    /**
     *
     * @return 返回有效肌电值
     */

    public float[] returnChosenData() {
        int length = (int) (end_Coordinate - start_Coordinate);
        chosenData = new float[length];
        for (int i = 0; i < length; i++) {
            chosenData[i] = comPonts[i+(int)start_Coordinate];

        }
        return chosenData;


    }

    public int getMdrawstate() {
        return finishPoint;
    }


}