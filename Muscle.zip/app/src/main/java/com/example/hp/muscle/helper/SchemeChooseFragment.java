package com.example.hp.muscle.helper;

import android.app.Fragment;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.example.hp.muscle.MainActivity;
import com.example.hp.muscle.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

/**
 * Created by hp on 2016/9/27.
 */
public class SchemeChooseFragment extends Fragment {
    @InjectView(R.id.brain)
    RadioButton brain;
    @InjectView(R.id.neck)
    RadioButton neck;
    @InjectView(R.id.waist)
    RadioButton waist;
    @InjectView(R.id.purpose)
    TextView purpose;
    @InjectView(R.id.testmethod)
    TextView testmethod;
    @InjectView(R.id.index)
    TextView index;
    @InjectView(R.id.position)
    TextView position;
    @InjectView(R.id.symlist)
    ListView symlist;
    @InjectView(R.id.bodydemo)
    ImageView bodydemo;
 /*   private Drawable[] bodyPic={getResources().getDrawable(R.drawable.image1),getResources().getDrawable(R.drawable.image2),
            getResources().getDrawable(R.drawable.image3),getResources().getDrawable(R.drawable.image4)};*/
    private List<Drawable> drawable;


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.right_fragment, container, false);
        ButterKnife.inject(this,view);
        return view;
    }
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        drawable = new ArrayList<Drawable>();
        drawable.add(getResources().getDrawable(R.drawable.image1));
        drawable.add(getResources().getDrawable(R.drawable.image2));
        drawable.add(getResources().getDrawable(R.drawable.image3));
        drawable.add(getResources().getDrawable(R.drawable.image4));
        RadioGroup sym_choose =(RadioGroup) getActivity().findViewById(R.id.sym_choose);
        sym_choose.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i) {
                    case R.id.brain:
                       /* ArrayAdapter<String> brainSym = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1,
                                getResources().getStringArray(R.array.brain));*/
                        MyAdapter brainSym = new MyAdapter(getActivity(), R.layout.selector_item, getResources().getStringArray(R.array.brain));
                        symlist.setAdapter(brainSym);
                        symlist.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
                        symlist.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                            public void onItemClick(AdapterView<?> parent,View view, int position, long id) {
                            setDemo(1,position);
                            }
                        });
                        break;
                    case R.id.neck:
                        MyAdapter neckSym = new MyAdapter(getActivity(), R.layout.selector_item, getResources().getStringArray(R.array.neck));
                        symlist.setAdapter(neckSym);
                        symlist.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
                        symlist.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                            public void onItemClick(AdapterView<?> parent,View view, int position, long id) {
                              setDemo(2,position);
                            }
                        });
                        break;
                    case R.id.waist:
                        MyAdapter waistSym = new MyAdapter(getActivity(), R.layout.selector_item, getResources().getStringArray(R.array.waist));
                        symlist.setAdapter(waistSym);
                        symlist.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
                        symlist.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                            public void onItemClick(AdapterView<?> parent,View view, int position, long id) {
                                setDemo(2,position);
                            }
                        });
                        break;
                }
            }
        });

    }

    public class MyAdapter extends ArrayAdapter<String> {
        private int resourceId;

        public MyAdapter(Context context, int textViewResourceId, String[] object) {
            super(context, textViewResourceId, object);
            resourceId = textViewResourceId;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            String string = getItem(position);
            View view = LayoutInflater.from(getContext()).inflate(resourceId, null);
            TextView s = (TextView) view.findViewById(R.id.string_3);
            s.setText(string);
            return view;
        }
    }





    /**
    a为三种主要症状对应的数组
     i为详细症状对应数组的位置
     */
    public void setDemo(int a,int i) {
        switch (a) {
            case 1:
                String pur=getResources().getStringArray(R.array.brainpurpose)[i];
                String ind = getResources().getStringArray(R.array.brainindex)[i];
                String method = getResources().getStringArray(R.array.brainmethod)[i];
                String pos = getResources().getStringArray(R.array.brainposition)[i];
                purpose.setText(pur);
                index.setText(ind);
                testmethod.setText(method);
                position.setText(pos);
                bodydemo.setImageDrawable(drawable.get(i%4));




                break;
            case 2:
                String pur1=getResources().getStringArray(R.array.brainpurpose)[i];
                String ind1 = getResources().getStringArray(R.array.brainindex)[i];
                String method1 = getResources().getStringArray(R.array.brainmethod)[i];
                String pos1 = getResources().getStringArray(R.array.brainposition)[i];
                purpose.setText(pur1);
                index.setText(ind1);
                testmethod.setText(method1);
                position.setText(pos1);
                bodydemo.setImageDrawable(drawable.get(i%4));
                break;
            case 3:
                String pur2=getResources().getStringArray(R.array.brainpurpose)[i];
                String ind2 = getResources().getStringArray(R.array.brainindex)[i];
                String method2 = getResources().getStringArray(R.array.brainmethod)[i];
                String pos2 = getResources().getStringArray(R.array.brainposition)[i];
                purpose.setText(pur2);
                index.setText(ind2);
                testmethod.setText(method2);
                position.setText(pos2);
                bodydemo.setImageDrawable(drawable.get(i%4));
                break;
            default:
                break;
        }

    }
}
