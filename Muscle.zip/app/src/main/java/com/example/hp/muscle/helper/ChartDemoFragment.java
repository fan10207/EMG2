package com.example.hp.muscle.helper;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hp.muscle.MainActivity;
import com.example.hp.muscle.R;
import com.example.hp.muscle.helper.bluetooth.AppFragment;
import com.example.hp.muscle.helper.bluetooth.BluetoothService;
import com.example.hp.muscle.helper.bluetooth.DeviceListActivity;
import com.example.hp.muscle.helper.bluetooth.Filter;
import com.example.hp.muscle.helper.bluetooth.SysApplication;
import com.example.hp.muscle.helper.chart.ChartView;
import com.example.hp.muscle.helper.fourier.FourierTran;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

import butterknife.InjectView;

/**
 * Created by hp on 2016/7/18.
 */
public class ChartDemoFragment extends AppFragment implements View.OnClickListener, PopupMenu.OnMenuItemClickListener {

    private ChartView mDataOneChart;
    private ChartView mDataTwoChart;
    private ChartView mDataThreeChart;
    private ChartView mDataFourChart;
    //存储需要显示的数据，线程安全的队列
    //放大倍数，初始值为1
    public static float scale = 1.2f;
    private static final int BLOCKING_QUEUE_SIZE = 1000;
    //放大电路的偏置电压
    public static float BIAS = 16.50f;
    //固定保存一定数量的数据来计算频谱
    private List<Float> frequencyArray = new LinkedList<>();
    //ADC 精度,0.805664mv
    public static final float AD = 0.805664f;
    //sample rate
    private static int mSampleRate = 400;
    //固定保存一定数量的数据来计算频谱
    private List<Float> tempArray = new LinkedList<>();
    //连续5个点幅值超过0.5，计算一次中心频率
    private List<Float> trigerArray = new LinkedList<>();

    //存通道数据
    private List<Float> Channel1 = new LinkedList<>();

    private TextView frequencyText;
    // private ChartView mSignalChart;
    private int frameNum = 280;
    private float maxData = 0f;
    private float mData = 0f;
    public static float threshold = 2000f;
    private Writer writerOne;//写肌电数组
    private Writer writerData;//写截取数据的数组
    private Filter filter;
    private int consta = 6;
    private int constb = 4;
    private int label = consta;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    public static final int REQUEST_ENABLE_BT = 0;
    public static final int REQUEST_CONNECT_DEVICE = 1;
    private BluetoothAdapter mBluetoothAdapter;
    public static int BLUETOOTH_CONNECT = 1;
    public static int BLUETOOTH_OPREN = 2;
    //  private FourierTran fourierTran;
    public float[] valueabledata;
    private double[] b1 = {0.1621, 0.328, -0.1468, -0.6253, -0.1468, 0.328, 0.1621};
    private double[] a1 = {1.134, -0.1204, 0.3858, -0.3186, -0.1138, -0.02828};
    private double[] b = {0.35, 0.25, 0.125};
    //对象锁
    private float[] datachannel1;
    private float[] freqData;
    //存起始点的容器
    private List<Integer> sp = new ArrayList<>();
    private List<Integer> ep = new ArrayList<>();
    /*  public int[] sp = new int[5000];
      public int[] ep = new int[5000];*/
    private final Object lock = new Object();

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.datacapture, container, false);
        return view;
    }


    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mDataOneChart = (ChartView) getActivity().findViewById(R.id.chartChannel1);
        mDataTwoChart = (ChartView) getActivity().findViewById(R.id.chartChannel2);
        mDataThreeChart = (ChartView) getActivity().findViewById(R.id.chartChannel3);
        mDataFourChart = (ChartView) getActivity().findViewById(R.id.chartChannel4);
        filter = new Filter();
        sharedPreferences = getActivity().getSharedPreferences("address", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        Button scan_bluetooth = (Button) getActivity().findViewById(R.id.scan_bluetooth);
        Button button_setting = (Button) getActivity().findViewById(R.id.button_setting);
        Button button_start = (Button) getActivity().findViewById(R.id.start_caculate);
        Button button_stopdrawing = (Button) getActivity().findViewById(R.id.stop_drawing);
        Button button_frequency = (Button) getActivity().findViewById(R.id.start_frequency);
        button_frequency.setOnClickListener(this);
        button_stopdrawing.setOnClickListener(this);
        scan_bluetooth.setOnClickListener(this);
        button_start.setOnClickListener(this);
        button_setting.setOnClickListener(this);

//建立要写文件的路径和对象
        File sd = Environment.getExternalStorageDirectory();
        String p = sd.getPath() + "/signal";
        File f = new File(p);
        if (!f.exists())
            f.mkdir();
        String path = "/mnt/sdcard/signal/" + new Date().getTime() + ".txt";
        final File fileOne = new File(path);
        try {
            writerOne = new FileWriter(fileOne, true);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //开启线程，等待蓝牙通信
        mHandler = new MyHandler(this);
        mChatService = new BluetoothService(context, mHandler);

    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.scan_bluetooth:
                Intent serverIntent = new Intent(context, DeviceListActivity.class);
                startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
                break;
            case R.id.button_setting:
                PopupMenu popup = new PopupMenu(getActivity(), view);
                MenuInflater inflater = popup.getMenuInflater();
                inflater.inflate(R.menu.menu_bluetooth, popup.getMenu());
                popup.setOnMenuItemClickListener(this);
                popup.show();
                break;
            case R.id.start_caculate:
                mChatService.stop();
                mDataOneChart.cleanChart();
                mDataTwoChart.cleanChart();
                mDataThreeChart.cleanChart();
                mDataFourChart.cleanChart();
                if (mDataOneChart.getMdrawstate() == 1) {
                    datachannel1 = new float[mDataOneChart.returnChosenData().length];
                    for (int i = 0; i < datachannel1.length; i++) {
                        datachannel1[i] = mDataOneChart.returnChosenData()[i];
                    }
                    findStartEnd(datachannel1, 500);
                    try {
                        valueabledata();
                        //if (writerData..)
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    mDataOneChart.demValueableData(valueabledata);
                } else {
                    Toast toast = Toast.makeText(getActivity(), "未设置起始点", Toast.LENGTH_SHORT);
                    toast.show();

                }
                break;
            case R.id.stop_drawing:
                Log.e(TAG, "onClick: stop"+mChatService.getState() );
                if (mChatService.getState() == BluetoothService.STATE_CONNECTED) {
                    mChatService.stop();
                    mDataOneChart.stopDrawing();
                    mDataTwoChart.stopDrawing();
                    mDataThreeChart.stopDrawing();
                    mDataFourChart.stopDrawing();
                } else {
                    Toast.makeText(getActivity(), "未开始连接设备", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.start_frequency:
                Log.e(TAG, "onClick: gogo");
                float AEMG = 0,
                        RMS = 0;
                if (valueabledata != null) {

                    for (int i = 0; i < valueabledata.length; i++) {
                        AEMG += Math.abs(valueabledata[i]);
                        RMS += valueabledata[i] * valueabledata[i];
                    }
                    AEMG = AEMG / valueabledata.length;
                    RMS = (float) Math.sqrt(RMS / valueabledata.length);
                    Bundle bundle = new Bundle();
                    bundle.putFloatArray("buffer", valueabledata);
                    bundle.putFloat("AEMG", AEMG);
                    bundle.putFloat("RMS", RMS);
                    FragmentTransaction transaction = getActivity().getFragmentManager().beginTransaction();
                    FrequencyFragment freqFragment = new FrequencyFragment();
                    transaction.replace(R.id.right_layout, freqFragment);
                    freqFragment.setArguments(bundle);
                    transaction.commit();
                } else {
                    Toast.makeText(getActivity(), "未选取有效数据", Toast.LENGTH_SHORT).show();
                }


                break;

        }
    }

    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_bluetooth:
                //打开蓝牙
                if (!mBluetoothAdapter.isEnabled()) {
                    Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
                } else
                    Toast.makeText(context, "bluetooth has already opened", Toast.LENGTH_LONG).show();
                return true;
            case R.id.menu_network:
                //网络功能控制

                return true;
            case R.id.menu_discoverable:
                //蓝牙可见性
                ensureDiscorverable();
                return true;
            case R.id.fifty_transmition:
                mChatService.startFiftyTransmition();
                return true;
            case R.id.stop_transmition:
                mChatService.stopTransmition();
                return true;
            case R.id.sixty_transmition:
                mChatService.startSixtyFrequency();
                return true;
            case R.id.flush:
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                int state = adapter.getState();
                if (state == BluetoothAdapter.STATE_ON) {
                    adapter.disable();
                }
                if (mChatService != null) {
                    mChatService.stop();
                }


                return true;
            case R.id.menu_exit:
                if (mChatService != null) {
                    mChatService.stop();
                }
                SysApplication.exit();
                return true;
            default:
                break;
        }
        return false;
    }


    private class MyHandler extends Handler {
        private WeakReference<Fragment> weakRefFragment;

        /**
         * a
         * A constructor that gets a weak reference to the enclosing class. We
         * do this to avoid memory leaks during Java Garbage Collection.
         */
        public MyHandler(Fragment fragment) {
            weakRefFragment = new WeakReference<Fragment>(fragment);
        }

        //重写handleMessage方法，用于处理消息
        @Override
        public void handleMessage(Message msg) {
            {
                float[] signal = new float[msg.arg1 / constb];
                float[] nosignal = new float[msg.arg1 / constb];
                for (int i = 0; i < msg.arg1 / constb; i++) {
                    signal[i] = 1000;
                    nosignal[i] = -1000;
                }
                float[] readBufOne = new float[msg.arg1 / constb];
                float[] readBufTwo = new float[msg.arg1 / constb];
                float[] readBufThree = new float[msg.arg1 / constb];
                float[] readBufFour = new float[msg.arg1 / constb];
                float[] envelope = new float[7];
                float envelopeSum = 0f;
                float envelopeAverage = 0f;
                //根据蓝牙传过来的数据进行处理
                switch (msg.what) {
                    case MESSAGE_READ:
                        float[] readBuf = (float[]) msg.obj;
                        int count = msg.arg1;
                        int cnt = 0;
                        for (int i = 0; i < count; i++) {
                            readBuf[i] = readBuf[i];

                            if (i % constb == 0) {
                                readBufOne[i / constb] = readBuf[i]; //出现 数组越界？
                                try {
                                    Channel1.add(readBuf[i]);

                                    writerOne.append(readBufOne[i / constb] + "" + "\n");
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            } else if (i % constb == 1) {
                                readBufTwo[(i - 1) / constb] = readBuf[i];

                            } else if (i % constb == 2) {
                                readBufThree[(i - 2) / constb] = readBuf[i];
                            } else {
                                readBufFour[(i - 3) / constb] = readBuf[i];
                            }
                            cnt = filter.zeroPass(readBuf[i]);
                            Log.d(TAG, "cnt" + cnt);
                            //取一帧的最大值,为了之后的幅值自适应
                            if (Math.abs(readBuf[i]) > mData) {
                                mData = Math.abs(readBuf[i]);
                            }
                        }
                        filter.count1 = 0;
                        if (frameNum > 0) {
                            maxData = mData;
                            frameNum--;
                        } else {
                            mDataOneChart.setAmplitude(4 * maxData);
                            //  mEnvelopeChart.setAmplitude(20 * maxData);
                        }
                        filter.getSum(readBuf);
                        mDataOneChart.updateFloats(readBufOne);
                        mDataTwoChart.updateFloats(readBufTwo);
                        mDataThreeChart.updateFloats(readBufThree);
                        mDataFourChart.updateFloats(readBufFour);
                        //mEnvelopeChart.updateFloats(envelope);
                        break;
                    case MESSAGE_STATE_CHANGE:
                        if (D)
                            Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                        switch (msg.arg1) {
                            case BluetoothService.STATE_CONNECTED:
                              /*  setStatus(getString(R.string.title_connected_to,
                                        mConnectedDeviceName));*/
                                break;
                            case BluetoothService.STATE_CONNECTING:
                            /*    setStatus(R.string.title_connecting);*/
                                break;
                            case BluetoothService.STATE_LISTEN:
                            case BluetoothService.STATE_NONE:
                            /*    setStatus(R.string.title_not_connected);*/
                                break;

                        }
                        break;
                    case MESSAGE_DEVICE_NAME:
                        // save the connected device's name
                        mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                        Toast.makeText(context,
                                "Connected to " + mConnectedDeviceName,
                                Toast.LENGTH_SHORT).show();
                        break;
                    case MESSAGE_TOAST:
                        Toast.makeText(context,
                                msg.getData().getString(TOAST), Toast.LENGTH_SHORT)
                                .show();
                        break;
                    case MESSAGE_TEXT:
                        frequencyText.setText(String.format("%.2f", (Float) msg.obj));
                        break;
                    default:
                        break;
                }
            }
        }
    }

//处理前面的开启DeviceListActivity的返回的结果
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        switch (requestCode) {
            case REQUEST_CONNECT_DEVICE:
                // When DeviceListActivity returns with a device to connect
                if (resultCode == Activity.RESULT_OK) {
                    Log.e(TAG, "bluetoothHandle: connect");
                    connectDevice(data);
                }
                break;
            case REQUEST_ENABLE_BT:
                // When the request to enable Bluetooth returns
                if (resultCode == Activity.RESULT_OK) {
                    // Bluetooth is now enabled, so set up a chat session
                    // setupChat();
                } else {
                    // User did not enable Bluetooth or an error occurred
                    Log.d(TAG, "BT not enabled");
                    Toast.makeText(context, R.string.bt_not_enabled_leaving,
                            Toast.LENGTH_SHORT).show();
                }
        }
    }

    public void connectDevice(Intent data) {
        String address = data.getExtras().getString(
                DeviceListActivity.EXTRA_DEVICE_ADDRESS);
        editor.putString("address", address);
        editor.commit();
        // Get the BluetoothDevice object
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        // Attempt to connect to the device
        getmChatService().connect(device);
    }


    public void ensureDiscorverable() {
        Log.d(TAG, "ensure discoverable");
        if (mBluetoothAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(
                    BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.putExtra(
                    BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivity(discoverableIntent);
        }
    }

    public void onDestroyView() {
        super.onDestroyView();
        Log.i(TAG, "--chartFragment onDestroyView---");
        try {
            writerOne.flush();
            writerOne.close();
            if (writerData != null) {
                writerData.flush();
                writerData.close();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        mHandler.removeCallbacksAndMessages(null);

    }
/**
buffer 需要计算起始点的数组
 L 计算噪声的前L个数据
 下面几个子函数为findStartEnd服务
 */
    public void findStartEnd(float[] buffer, int L) {
        int length = buffer.length;
        float[] Yk = new float[length];
        float[] Yk1 = new float[length];
        float[] Y = new float[length];
        for (int i = 0; i < 6; i++) {
            Yk[i] = 0;
        }

        /**
        计算包络线
         */
        for (int i = 6; i < length; i++) {
            Yk1[i] = (float) (b1[0] * buffer[i] + b1[1] * buffer[i - 1] + b1[2] * buffer[i - 2] + b1[3] * buffer[i - 3] + b1[4] * buffer[i - 4] + b1[5] * buffer[i - 5]);
            Yk1[i] += (float) (a1[0] * Yk[i - 1] + a1[1] * Yk[i - 2] + a1[2] * Yk[i - 3] + a1[3] * Yk[i - 4] + a1[4] * Yk[i - 5] + a1[5] * Yk[i - 6]);
        }
        for (int i = 0; i < length; i++) {
            Yk[i] = Math.abs(Yk1[i]);
        }

        for (int i = 0; i < 3; i++) {
            Y[i] = 0;
        }
        for (int a = 3; a < length; a++) {
            Y[a] = (float) (Y[a - 1] * b[0] + Y[a - 2] * b[1] + Y[a - 3] * b[2] + 0.125 * Yk[a] + 0.1 * Yk[a - 1] + 0.05 * Yk[a - 2]);
        }
        /**
         * 调用noiceSrms（）函数计算噪声阈值
         */
        float noice = noiceSrms(Y, L);
        int a = 0;
        int n = 32;
        int win = 64;
        int i = 0;
        while (a + 5 * win <= length) {

            float detect = srms(Y, a);

            if ((detect > 2000 || detect < noice)) {
                a = a + n;
                continue;
            }
            sp.add(a);//是肌电信号，记录起点
            Log.e(TAG, "findStartEnd: sp[" + i + "]" + a);
            while ((detect >= noice) && (a + win < length)) {

                detect = srms(Y, a);
                a = a + n;
            }
            ep.add(a);//有效肌电部分过去，记下终点
            Log.e(TAG, "findStartEnd: ep[" + i + "]" + a);
            i = i + 1;
            a = a + n;
        }

    }

    /**
     *
     * @param count 需要计算的肌电数据 数组
     * @param L 代表用于计算噪声阈值的数据长度
     * @return
     */
    public float noiceSrms(float[] count, int L) {
        float noiceSrms = 0;
        float variance = 0;
        for (int i = 0; i < L; i++) {
            noiceSrms += count[i] / L;

        }
        for (int i = 0; i < L; i++) {
            variance += ((Math.abs(count[i]) - noiceSrms) * (Math.abs(count[i]) - noiceSrms) / (L - 1));
        }
        variance = (float) Math.sqrt(variance);

        return noiceSrms + 3 * variance;
    }

    /**
     *
     * @param count 肌电数据数组
     * @param sysbom 当前移窗的位置
     * @return
     */
    public float srms(float[] count, int sysbom) {
        float srms = 0;
        int n = 64;
        for (int i = sysbom; i < sysbom + n - 1; i++) {
            srms += Math.abs(count[i]) / n;
        }
        return srms;
    }


    /**
     * @return data to find the frequency domain index
     */

    public void valueabledata() throws IOException {
        int length = sp.size();

        int valuelength = 0;
        for (int i = 0; i < length; i++) {
            valuelength = valuelength + ep.get(i) - sp.get(i);


        }

        File sd = Environment.getExternalStorageDirectory();
        String p = sd.getPath() + "/aatext";
        File f = new File(p);
        if (!f.exists())
            f.mkdir();
        String path = "/mnt/sdcard/aatext/" + new Date().getTime() + ".txt";
        final File fileData = new File(path);
        try {
            writerData = new FileWriter(fileData, true);
        } catch (IOException e) {
            e.printStackTrace();
        }

        valueabledata = new float[valuelength];
        for (int i = 0, a = 0, b = 0; (i < datachannel1.length) && (b < valuelength); i++) {
            if (i >= sp.get(a)) {
                valueabledata[b] = datachannel1[i];
                writerData.append(valueabledata[b] + "" + "\n");
                b++;


            }
            if (i >= ep.get(a))
                a++;
        }
    }

}
